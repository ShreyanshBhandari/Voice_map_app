document.addEventListener("DOMContentLoaded", function() {
    var map = L.map('map').setView([51.505, -0.09], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    var recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    var isListening = false;

    recognition.onresult = function(event) {
        var command = event.results[0][0].transcript.toLowerCase();
        handleCommand(command);
    };

    recognition.onend = function() {
        if (isListening) {
            recognition.start(); // Restart recognition if still listening
        }
    };

    recognition.onerror = function(event) {
        console.error('Error occurred in recognition: ' + event.error);
    };

    function startVoiceRecognition() {
        if (!isListening) {
            recognition.start();
            isListening = true;
        }
    }

    function stopVoiceRecognition() {
        if (isListening) {
            recognition.stop();
            isListening = false;
        }
    }

    var voiceButton = document.getElementById("voice-button");
    voiceButton.addEventListener("click", function() {
        if (!isListening) {
            startVoiceRecognition();
        } else {
            stopVoiceRecognition();
        }
    });

    function handleCommand(command) {
        try {
            var parsedCommand = parseCommand(command);
            executeAction(parsedCommand.action, parsedCommand.location, parsedCommand.layer);
        } catch (error) {
            console.error('Error handling command:', error);
            alert('Error handling command. Please try again.');
        }
    }

    function parseCommand(command) {
        // Basic keyword-based parsing for demonstration
        let action = '';
        let location = '';
        let layer = '';

        if (command.includes('zoom in')) {
            action = 'zoom_in';
        } else if (command.includes('zoom out')) {
            action = 'zoom_out';
        } else if (command.includes('show map of')) {
            action = 'show_map';
            location = command.split('show map of ')[1];
        } else if (command.includes('show my location')) {
            action = 'show_current_location';
        } else if (command.includes('show vegetation of')) {
            action = 'show_layer';
            layer = 'vegetation';
            location = command.split('show vegetation of ')[1];
        } else if (command.includes('show satellite view of')) {
            action = 'show_layer';
            layer = 'satellite';
            location = command.split('show satellite view of ')[1];
        } else if (command.includes('stop')) {
            stopVoiceRecognition();
        } else if (command.includes('start')) {
            startVoiceRecognition();
        } else {
            throw new Error('Unknown command');
        }

        return { action, location, layer };
    }

    function executeAction(action, location, layer) {
        switch (action) {
            case 'zoom_in':
                map.zoomIn();
                break;
            case 'zoom_out':
                map.zoomOut();
                break;
            case 'show_map':
                if (location) {
                    geocodeLocation(location).then(coords => {
                        map.setView(coords, 13);
                        L.marker(coords).addTo(map)
                            .bindPopup('Location: ' + location)
                            .openPopup();
                    }).catch(error => {
                        console.error('Error geocoding location:', error);
                        alert('Error geocoding location. Please try again.');
                    });
                } else {
                    alert('Location not specified');
                }
                break;
            case 'show_current_location':
                navigator.geolocation.getCurrentPosition(function(position) {
                    var lat = position.coords.latitude;
                    var lon = position.coords.longitude;
                    map.setView([lat, lon], 13);
                    L.marker([lat, lon]).addTo(map)
                        .bindPopup('You are here!')
                        .openPopup();
                });
                break;
            case 'show_layer':
                if (location && layer) {
                    geocodeLocation(location).then(coords => {
                        map.setView(coords, 13);
                        addLayer(layer, coords, location);
                    }).catch(error => {
                        console.error('Error geocoding location:', error);
                        alert('Error geocoding location. Please try again.');
                    });
                } else {
                    alert('Layer or location not specified');
                }
                break;
            default:
                console.warn('Unknown action:', action);
        }
    }

    async function geocodeLocation(location) {
        try {
            const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${location}`);
            const data = await response.json();
            if (data && data.length > 0) {
                const { lat, lon } = data[0];
                return [parseFloat(lat), parseFloat(lon)];
            } else {
                throw new Error('Location not found');
            }
        } catch (error) {
            throw new Error('Error geocoding location');
        }
    }

    function addLayer(layerType, coords, location) {
        // Remove existing layers
        map.eachLayer(function (layer) {
            if (layer.options && layer.options.attribution !== '© OpenStreetMap contributors') {
                map.removeLayer(layer);
            }
        });

        // Add new layer
        let layerUrl = '';
        if (layerType === 'vegetation') {
            layerUrl = 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png'; // Example vegetation layer URL
        } else if (layerType === 'satellite') {
            layerUrl = 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png'; // Example satellite layer URL
        }

        L.tileLayer(layerUrl, {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);

        L.marker(coords).addTo(map)
            .bindPopup(`${layerType.charAt(0).toUpperCase() + layerType.slice(1)} layer of ${location}`)
            .openPopup();
    }
});
